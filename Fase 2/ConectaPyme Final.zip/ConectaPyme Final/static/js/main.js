document.addEventListener('DOMContentLoaded', function() {
    // --- LÓGICA DEL PANEL DE CHAT ---
    const currentUserCompanyId = document.body.dataset.companyId;
    if (!currentUserCompanyId) return;

    const chatPanel = document.getElementById('chat-panel-container');
    const toggleButton = document.getElementById('toggle-chat-panel');
    const closeButton = document.getElementById('chat-close-btn');
    const startChatButton = document.getElementById('start-chat-btn');

    if (!chatPanel) return;

    // Abrir/cerrar panel desde el navbar
    if (toggleButton) {
        toggleButton.addEventListener('click', () => {
            chatPanel.classList.toggle('open');
            if (chatPanel.classList.contains('open')) {
                fetchThreads();
            }
        });
    }

    // Iniciar chat desde un perfil (si existe ese botón en esa página)
    if (startChatButton) {
        startChatButton.addEventListener('click', async () => {
            const companyId = startChatButton.dataset.companyId;
            const companyName = startChatButton.dataset.companyName;

            const response = await fetch(`/mensajes/api/threads/start/${companyId}/`);
            const data = await response.json();
            const threadId = data.thread_id;

            chatPanel.classList.add('open');
            openChatWindow(threadId, companyName);
        });
    }

    closeButton?.addEventListener('click', () => chatPanel.classList.remove('open'));

    let activeThreadId = null;
    let chatSocket = null;
    const threadListView = document.getElementById('thread-list-view');
    const chatWindowView = document.getElementById('chat-window-view');

    async function fetchThreads() {
        const response = await fetch('/mensajes/api/threads/');
        const threads = await response.json();
        renderThreads(threads);
    }

    function renderThreads(threads) {
        const threadListBody = document.getElementById('thread-list-body');
        threadListBody.innerHTML = '';
        threads.forEach(thread => {
            const otherParticipant = thread.participants.find(p => p.pk != currentUserCompanyId);
            if (!otherParticipant) return;
            const threadDiv = document.createElement('div');
            threadDiv.className = 'p-2 border-bottom';
            threadDiv.style.cursor = 'pointer';
            threadDiv.innerHTML = `<strong>${otherParticipant.company_name}</strong>`;
            threadDiv.addEventListener('click', () => openChatWindow(thread.pk, otherParticipant.company_name));
            threadListBody.appendChild(threadDiv);
        });
    }

    async function openChatWindow(threadId, recipientName) {
        activeThreadId = threadId;
        document.getElementById('chat-window-recipient').innerText = recipientName || `Hilo #${threadId}`;

        const response = await fetch(`/mensajes/api/threads/${threadId}/messages/`);
        const messages = await response.json();
        const messagesDiv = document.getElementById('chat-window-messages');
        messagesDiv.innerHTML = '';
        messages.forEach(msg => {
            const msgDiv = document.createElement('p');
            msgDiv.className = 'mb-1';
            // Ajusta las keys según tu serializer real:
            // msg.sender.company_name / msg.text / msg.timestamp
            msgDiv.innerHTML = `<strong>${(msg.sender?.company_name) || 'Usuario'}:</strong> ${msg.text || msg.message || ''}`;
            messagesDiv.appendChild(msgDiv);
        });
        messagesDiv.scrollTop = messagesDiv.scrollHeight;

        chatWindowView.classList.remove('d-none');
        threadListView.classList.add('d-none');
        connectWebSocket(threadId);
    }

    function connectWebSocket(threadId) {
        if (chatSocket) chatSocket.close();
        const proto = (location.protocol === 'https:') ? 'wss' : 'ws';
        chatSocket = new WebSocket(`${proto}://${window.location.host}/ws/chat/${threadId}/`);
        chatSocket.onmessage = function(e) {
            const data = JSON.parse(e.data);
            const messagesDiv = document.getElementById('chat-window-messages');
            const msgDiv = document.createElement('p');
            msgDiv.className = 'mb-1';
            msgDiv.innerHTML = `<strong>${data.sender_company_name || 'Nuevo'}:</strong> ${data.message || ''}`;
            messagesDiv.appendChild(msgDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        };
    }

    document.getElementById('chat-back-btn')?.addEventListener('click', () => {
        chatWindowView.classList.add('d-none');
        threadListView.classList.remove('d-none');
        if (chatSocket) chatSocket.close();
        activeThreadId = null;
        fetchThreads();
    });

    const messageInput = document.getElementById('chat-message-input');
    document.getElementById('chat-message-submit')?.addEventListener('click', function() {
        if (messageInput.value.trim().length > 0 && chatSocket) {
            chatSocket.send(JSON.stringify({ 'message': messageInput.value }));
            messageInput.value = '';
        }
    });
    messageInput?.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            document.getElementById('chat-message-submit')?.click();
        }
    });

    // === EXPONER API PARA EL BRIDGE ===
    window.ChatUI = window.ChatUI || {};
    window.ChatUI.openThread = function(threadId, meta = {}) {
        chatPanel.classList.add('open');                // muestra la isla
        openChatWindow(threadId, meta.companyName || ''); // reutiliza tu flujo completo
    };
});

// ==== (tus otras funcionalidades de main.js siguen aquí) ====

document.addEventListener('DOMContentLoaded', function() {
    // --- 1. VALIDACIÓN DE CONTRASEÑAS ---
    const passwordInput = document.getElementById('id_password');
    const confirmPasswordInput = document.getElementById('id_password_confirm');
    if (passwordInput && confirmPasswordInput) {
        const messageDiv = document.createElement('div');
        messageDiv.id = 'password-match-message';
        const parentDiv = confirmPasswordInput.closest('.mb-3');
        if (parentDiv) parentDiv.appendChild(messageDiv);

        function validatePasswords() {
            if (confirmPasswordInput.value === '') {
                messageDiv.textContent = '';
                confirmPasswordInput.classList.remove('is-valid', 'is-invalid');
                return;
            }
            if (passwordInput.value === confirmPasswordInput.value) {
                messageDiv.textContent = 'Las contraseñas coinciden.';
                messageDiv.className = 'text-success small mt-1';
                confirmPasswordInput.classList.remove('is-invalid');
                confirmPasswordInput.classList.add('is-valid');
            } else {
                messageDiv.textContent = 'Las contraseñas no coinciden.';
                messageDiv.className = 'text-danger small mt-1';
                confirmPasswordInput.classList.remove('is-valid');
                confirmPasswordInput.classList.add('is-invalid');
            }
        }
        passwordInput.addEventListener('keyup', validatePasswords);
        confirmPasswordInput.addEventListener('keyup', validatePasswords);
    }

    // --- 2. VALIDACIÓN DE USERNAME ---
    const usernameInput = document.querySelector('#id_username');
    if (usernameInput) {
        let timeout = null;
        usernameInput.addEventListener('keyup', function(e) {
            clearTimeout(timeout);
            const username = e.target.value;
            timeout = setTimeout(function() {
                if (username.length > 2) {
                    fetch(`/accounts/validate-username/?username=${encodeURIComponent(username)}`)
                        .then(response => response.json())
                        .then(data => {
                            const feedbackDiv = usernameInput.parentNode.querySelector('.invalid-feedback');
                            if (data.is_taken) {
                                usernameInput.classList.add('is-invalid');
                                usernameInput.classList.remove('is-valid');
                                if (feedbackDiv) feedbackDiv.innerText = 'Este nombre de usuario ya está en uso.';
                            } else {
                                usernameInput.classList.remove('is-invalid');
                                usernameInput.classList.add('is-valid');
                            }
                        });
                } else {
                    usernameInput.classList.remove('is-valid', 'is-invalid');
                }
            }, 500);
        });
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('id_password');
    if (!passwordInput) return;

    const meterContainer = document.createElement('div');
    meterContainer.className = 'mt-2';
    const strengthBar = document.createElement('div');
    strengthBar.className = 'progress';
    strengthBar.style.height = '5px';
    const strengthBarInner = document.createElement('div');
    strengthBarInner.className = 'progress-bar';
    strengthBarInner.setAttribute('role', 'progressbar');
    strengthBar.appendChild(strengthBarInner);

    const requirementsList = document.createElement('ul');
    requirementsList.className = 'list-unstyled small text-muted mt-2';
    requirementsList.innerHTML = `
        <li id="length-req"><i class="fas fa-times-circle me-2 text-danger"></i>Mínimo 8 caracteres</li>
        <li id="number-req"><i class="fas fa-times-circle me-2 text-danger"></i>Contiene un número</li>
        <li id="upper-req"><i class="fas fa-times-circle me-2 text-danger"></i>Contiene una mayúscula</li>
    `;

    meterContainer.appendChild(strengthBar);
    meterContainer.appendChild(requirementsList);
    passwordInput.parentNode.appendChild(meterContainer);

    passwordInput.addEventListener('keyup', function() {
        const password = passwordInput.value;
        let score = 0;

        const lengthReq = document.getElementById('length-req');
        if (password.length >= 8) {
            score++;
            lengthReq.innerHTML = '<i class="fas fa-check-circle me-2 text-success"></i>Mínimo 8 caracteres';
        } else {
            lengthReq.innerHTML = '<i class="fas fa-times-circle me-2 text-danger"></i>Mínimo 8 caracteres';
        }

        const numberReq = document.getElementById('number-req');
        if (/\d/.test(password)) {
            score++;
            numberReq.innerHTML = '<i class="fas fa-check-circle me-2 text-success"></i>Contiene un número';
        } else {
            numberReq.innerHTML = '<i class="fas fa-times-circle me-2 text-danger"></i>Contiene un número';
        }

        const upperReq = document.getElementById('upper-req');
        if (/[A-Z]/.test(password)) {
            score++;
            upperReq.innerHTML = '<i class="fas fa-check-circle me-2 text-success"></i>Contiene una mayúscula';
        } else {
            upperReq.innerHTML = '<i class="fas fa-times-circle me-2 text-danger"></i>Contiene una mayúscula';
        }

        const percentage = (score / 3) * 100;
        strengthBarInner.style.width = percentage + '%';
        strengthBarInner.classList.remove('bg-danger', 'bg-warning', 'bg-success');
        if (score === 1) strengthBarInner.classList.add('bg-danger');
        else if (score === 2) strengthBarInner.classList.add('bg-warning');
        else if (score === 3) strengthBarInner.classList.add('bg-success');
    });
});
