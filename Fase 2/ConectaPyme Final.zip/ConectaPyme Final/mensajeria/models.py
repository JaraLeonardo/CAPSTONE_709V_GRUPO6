from django.db import models
from perfiles.models import Company # Importamos el modelo de la empresa

class Thread(models.Model):
    participants = models.ManyToManyField(Company, related_name='threads')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Conversación entre {self.participants.count()} participantes'

class ChatMessage(models.Model):
    thread = models.ForeignKey(Thread, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(Company, on_delete=models.CASCADE)
    text = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Mensaje de {self.sender.company_name} en {self.timestamp.strftime("%d-%m-%Y")}'
    
