from django.shortcuts import get_object_or_404, render, redirect
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.db.models import Q

from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated

from .models import Thread, ChatMessage
from perfiles.models import Company
from .serializers import ThreadSerializer, ChatMessageSerializer

# ----------------------------
# Iniciar o recuperar Thread (JSON)
# ----------------------------
@login_required
def start_or_get_thread(request, company_id):
    other_company = get_object_or_404(Company, pk=company_id)
    my_company = request.user.company

    # Busca si ya existe una conversación entre los dos (M2M 'participants')
    thread = Thread.objects.filter(participants=my_company)\
                           .filter(participants=other_company)\
                           .first()

    if not thread:
        # Si no existe, creamos una nueva conversación
        thread = Thread.objects.create()
        thread.participants.add(my_company, other_company)
    
    # Devolvemos el ID del hilo en formato JSON (útil si lo llamas vía fetch/axios)
    return JsonResponse({'thread_id': thread.pk})

# ----------------------------
# API: Lista de hilos del usuario
# ----------------------------
class ThreadListAPIView(ListAPIView):
    serializer_class = ThreadSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Thread.objects.filter(participants=self.request.user.company).order_by('-updated')

# ----------------------------
# API: Mensajes de un hilo
# ----------------------------
class MessageListAPIView(ListAPIView):
    serializer_class = ChatMessageSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        thread_pk = self.kwargs['pk']
        thread = get_object_or_404(Thread, pk=thread_pk, participants=self.request.user.company)
        return ChatMessage.objects.filter(thread=thread).order_by('timestamp')

# ----------------------------
# Inbox con soporte de start_with (fallback opcional)
# ----------------------------
@login_required
def inbox(request):
    start_with = request.GET.get("start_with")
    if start_with and hasattr(request.user, "company"):
        my_company = request.user.company
        target = get_object_or_404(Company, pk=start_with)

        # M2M participants (tu modelo actual)
        thread = (Thread.objects.filter(participants=my_company)
                              .filter(participants=target)
                              .first())
        if not thread:
            thread = Thread.objects.create()
            thread.participants.add(my_company, target)
        return redirect("mensajeria:thread_detail", pk=thread.pk)

    # Render normal de inbox (ajusta al template que uses)
    return render(request, "mensajeria/inbox.html", {})
