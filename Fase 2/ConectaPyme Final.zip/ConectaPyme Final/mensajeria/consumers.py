import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import Thread, ChatMessage
from perfiles.models import Company

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope['user']
        if not self.user.is_authenticated:
            await self.close()
            return

        self.user_company = await self.get_user_company()
        if not self.user_company:
            await self.close()
            return
            
        self.room_name = self.scope['url_route']['kwargs']['thread_id']
        self.room_group_name = f'chat_{self.room_name}'

        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message = text_data_json['message']
        
        # Guardamos el nuevo mensaje en la base de datos de forma asíncrona
        await self.save_message(message)

        # Enviamos el mensaje al grupo del canal
        await self.channel_layer.group_send(
            self.room_group_name, {
                'type': 'chat_message',
                'message': message,
                'sender_company_name': self.user_company.company_name
            }
        )

    async def chat_message(self, event):
        message = event['message']
        sender_company_name = event['sender_company_name']

        await self.send(text_data=json.dumps({
            'message': message,
            'sender_company_name': sender_company_name
        }))

    # --- FUNCIONES ASÍCRONAS PARA LA BASE DE DATOS ---

    @database_sync_to_async
    def get_user_company(self):
        try:
            return self.user.company
        except Company.DoesNotExist:
            return None

    # ESTA FUNCIÓN NECESITA EL DECORADOR
    @database_sync_to_async
    def save_message(self, message_text):
        thread = Thread.objects.get(pk=self.room_name)
        ChatMessage.objects.create(
            thread=thread,
            sender=self.user_company,
            text=message_text
        )