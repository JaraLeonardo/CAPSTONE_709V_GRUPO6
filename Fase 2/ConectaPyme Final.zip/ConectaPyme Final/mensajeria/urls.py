# mensajeria/urls.py
from django.urls import path
from .views import (
    start_or_get_thread,
    ThreadListAPIView,
    MessageListAPIView,
    inbox,  # si no lo usas, igual puede quedar
)

app_name = "mensajeria"

urlpatterns = [
    # API para iniciar/obtener un hilo (lo usa la isla flotante)
    path('api/threads/start/<int:company_id>/', start_or_get_thread, name='start_thread'),

    # APIs que tu panel flotante puede consumir
    path('api/threads/', ThreadListAPIView.as_view(), name='api_thread_list'),
    path('api/threads/<int:pk>/messages/', MessageListAPIView.as_view(), name='api_message_list'),

    # (Opcional) Bandeja de entrada si la usas
    path('', inbox, name='inbox'),
]
