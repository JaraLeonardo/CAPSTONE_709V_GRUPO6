from rest_framework import serializers
from .models import Thread, ChatMessage
from perfiles.models import Company

class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['pk', 'company_name']

class ChatMessageSerializer(serializers.ModelSerializer):
    sender = CompanySerializer(read_only=True)

    class Meta:
        model = ChatMessage
        fields = ['id', 'sender', 'text', 'timestamp']

class ThreadSerializer(serializers.ModelSerializer):
    participants = CompanySerializer(many=True, read_only=True)
    last_message = serializers.SerializerMethodField()

    class Meta:
        model = Thread
        fields = ['pk', 'participants', 'updated', 'last_message']
    
    def get_last_message(self, obj):
        last_msg = obj.messages.last()
        if last_msg:
            return ChatMessageSerializer(last_msg).data
        return None