from django.db.models.signals import post_save
from django.dispatch import receiver
from django.urls import reverse
from .models import ChatMessage, Thread
from notificaciones.models import Notification
from django.contrib.contenttypes.models import ContentType
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

@receiver(post_save, sender=ChatMessage)
def create_message_notification(sender, instance, created, **kwargs):
    if created:
        thread = instance.thread
        sender_company = instance.sender
        
        for participant in thread.participants.all():
            if participant != sender_company:
                recipient = participant
                
                content_type = ContentType.objects.get_for_model(Thread)
                
                # Busca o crea una notificación no leída para este chat
                existing_notification, is_new = Notification.objects.update_or_create(
                    recipient=recipient,
                    content_type=content_type,
                    object_id=thread.pk,
                    read=False,
                    defaults={
                        'sender': sender_company,
                        'target_url': reverse('perfil_negocio', kwargs={'pk': sender_company.pk})
                    }
                )

                if not is_new:
                    # Si la notificación ya existía, incrementamos el contador
                    existing_notification.count += 1
                    existing_notification.verb = f'{sender_company.company_name} te ha enviado {existing_notification.count} nuevos mensajes.'
                    existing_notification.save()
                else:
                    # Si se acaba de crear, ponemos el mensaje inicial
                    existing_notification.verb = f'{sender_company.company_name} te ha enviado un nuevo mensaje.'
                    existing_notification.save()
                
                # Enviamos la notificación (nueva o actualizada) en tiempo real
                send_notification_realtime(recipient.pk, existing_notification.verb)

def send_notification_realtime(recipient_pk, message):
    channel_layer = get_channel_layer()
    group_name = f'notifications_{recipient_pk}'
    async_to_sync(channel_layer.group_send)(
        group_name,
        {'type': 'send.notification', 'message': message}
    )