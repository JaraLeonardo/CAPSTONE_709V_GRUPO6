from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    # Usamos re_path para capturar el ID de la conversación (thread) de la URL
    re_path(r'ws/chat/(?P<thread_id>\d+)/$', consumers.ChatConsumer.as_asgi()),
]