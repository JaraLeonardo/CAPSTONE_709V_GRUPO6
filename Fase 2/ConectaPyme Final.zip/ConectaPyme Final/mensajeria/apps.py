from django.apps import AppConfig

class MensajeriaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mensajeria'

    def ready(self):
        # Importa las señales para que se registren cuando la app esté lista
        import mensajeria.signals