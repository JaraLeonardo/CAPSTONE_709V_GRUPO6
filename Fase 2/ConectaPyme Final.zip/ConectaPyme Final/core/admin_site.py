# core/admin_site.py
from django.contrib import admin
from django.contrib.admin import AdminSite
from django.contrib.admin.sites import AlreadyRegistered
from django.urls import path
from django.db.models import Count, DateTimeField
from django.db.models.functions import TruncWeek
from django.utils.timezone import now
from django.shortcuts import render

from Cuenta.models import CustomUser
from perfiles.models import Company

class ConectaAdminSite(AdminSite):
    site_header = "ConectaPyme Admin"
    site_title = "ConectaPyme"
    index_title = "Panel de Control"
    # index_template = "admin/custom_index.html"  # (opcional: si quieres un index distinto)

    def get_urls(self):
        urls = super().get_urls()
        my_urls = [
            path("dashboard/", self.admin_view(self.dashboard_view), name="custom-dashboard"),
        ]
        return my_urls + urls

    def dashboard_view(self, request):
        signups_by_week = (
            CustomUser.objects
            .annotate(week=TruncWeek("date_joined", output_field=DateTimeField()))
            .values("week").order_by("week").annotate(total=Count("id"))
        )
        companies_by_sector = (
            Company.objects.values("sector").annotate(total=Count("sector")).order_by("-total")[:10]
        )
        latest_companies = Company.objects.select_related("user").order_by("-pk")[:10]

        context = {
            "now": now(),
            "total_empresas": Company.objects.count(),
            "total_usuarios": CustomUser.objects.count(),
            "signups_by_week": list(signups_by_week),
            "companies_by_sector": list(companies_by_sector),
            "latest_companies": latest_companies,
        }
        return render(request, "admin/dashboard.html", context)

# Instancia global del AdminSite personalizado
admin_site = ConectaAdminSite(name="conecta_admin")


# ---------- Helper para registrar en ambos admin sites ----------
def register_both(model, admin_class):
    """Registra un modelo en admin.site (clásico) y en admin_site (personalizado), ignorando duplicados."""
    for site in (admin.site, admin_site):
        try:
            site.register(model, admin_class)
        except AlreadyRegistered:
            pass
