from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.views.generic import TemplateView, UpdateView, DetailView, ListView, CreateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.http import require_POST
from django.contrib.auth import logout
from django.http import JsonResponse
from django.db.models import Q, Count, DateTimeField
from django.db.models.functions import TruncWeek
from django.contrib import messages
from django.utils.timezone import now
from django.conf import settings
from django.db.models import Prefetch
from django.db import transaction

from Cuenta.models import CustomUser
from .models import Company, Product, Post, Review, Comment, ContentReport, REVIEW_STATUS, COMMENT_STATUS
from .forms import CompanyProfileForm, ReviewForm, ProductForm, PostForm, CommentForm
from .simpleapi import query_simpleapi_rut


# =====================================================
# Helpers / permisos
# =====================================================

def is_moderator(user):
    return user.is_authenticated and getattr(user, 'user_type', '') in ['ADMIN', 'MODERATOR']

def _can_moderate_review(user, review: Review) -> bool:
    """Permisos: admin/staff/superuser o dueño del perfil (empresa objetivo)."""
    if not user.is_authenticated:
        return False
    if user.is_staff or user.is_superuser:
        return True
    user_company_id = getattr(getattr(user, "company", None), "pk", None)
    return bool(user_company_id and review.target_company_id == user_company_id)

# =====================================================
# Páginas estáticas
# =====================================================

class HomeView(TemplateView):
    template_name = 'home.html'

class FaqView(TemplateView):
    template_name = 'faq.html'


# =====================================================
# Dashboard general
# =====================================================

@login_required
def dashboard(request):
    user = request.user
    if getattr(user, 'user_type', '') == 'ADMIN' or user.is_staff or user.is_superuser:
        return redirect('admin_portal_dashboard')

    context = {}
    if getattr(user, 'user_type', '') in ['PYME', 'DISTRIBUTOR']:
        company = getattr(user, 'company', None)
        if request.method == 'POST':
            post_form = PostForm(request.POST)
            if not company:
                messages.error(request, "No tienes empresa asociada.")
                return redirect('dashboard')
            if post_form.is_valid():
                post = post_form.save(commit=False)
                post.company = company
                post.save()
                messages.success(request, "Publicación creada.")
                return redirect('dashboard')
        else:
            post_form = PostForm()

        context['company'] = company
        context['post_form'] = post_form

    return render(request, 'dashboard.html', context)


# =====================================================
# Portal admin
# =====================================================

@staff_member_required
def admin_portal_dashboard(request):
    total_empresas = Company.objects.count()
    total_usuarios = CustomUser.objects.count()
    verified_count = Company.objects.filter(is_verified=True).count()
    unverified_count = total_empresas - verified_count

    signups = (
        CustomUser.objects
        .annotate(week=TruncWeek("date_joined", output_field=DateTimeField()))
        .values("week")
        .order_by("week")
        .annotate(total=Count("id"))
    )

    sectors = (
        Company.objects
        .values("sector")
        .annotate(total=Count("pk"))  # Company usa pk (user_id) como clave
        .order_by("-total")[:10]
    )

    query_rut = request.GET.get("rut", "").strip()
    found_company = None
    if query_rut:
        normalized = query_rut.replace(".", "").replace(" ", "")
        found_company = Company.objects.filter(
            Q(Rut__iexact=query_rut) | Q(Rut__iexact=normalized)
        ).first()
        if not found_company:
            messages.warning(request, f"No se encontró empresa con RUT '{query_rut}'.")

    latest_unverified = Company.objects.filter(is_verified=False).order_by("-pk")[:10]
    latest_companies = Company.objects.order_by("-pk")[:10]

    context = {
        "now": now(),
        "total_empresas": total_empresas,
        "total_usuarios": total_usuarios,
        "verified_count": verified_count,
        "unverified_count": unverified_count,
        "signups_by_week": list(signups),
        "companies_by_sector": list(sectors),
        "latest_unverified": latest_unverified,
        "latest_companies": latest_companies,
        "query_rut": query_rut,
        "found_company": found_company,
    }
    return render(request, "admin_portal_dashboard.html", context)


@staff_member_required
@require_POST
def verify_company_admin(request, pk):
    company = get_object_or_404(Company, pk=pk)
    note = request.POST.get("verification_note", "").strip()
    if hasattr(company, "verify"):
        company.verify(by_user=request.user, note=note)
    else:
        company.is_verified = True
        company.save(update_fields=["is_verified"])
    messages.success(request, f"Empresa '{company.company_name}' verificada.")
    return redirect("admin_portal_dashboard")


@staff_member_required
@require_POST
def unverify_company_admin(request, pk):
    company = get_object_or_404(Company, pk=pk)
    note = request.POST.get("verification_note", "").strip()
    if hasattr(company, "unverify"):
        company.unverify(by_user=request.user, note=note)
    else:
        company.is_verified = False
        company.save(update_fields=["is_verified"])
    messages.info(request, f"Empresa '{company.company_name}' marcada como NO verificada.")
    return redirect("admin_portal_dashboard")


# =====================================================
# Listado público de empresas
# =====================================================

class CompanyListView(ListView):
    model = Company
    template_name = 'company_list.html'
    context_object_name = 'company_list'
    paginate_by = 12  # 12 por página para cuadrícula

    def get_queryset(self):
        qs = (
            super().get_queryset()
            .filter(is_verified=True, is_active=True)
            .select_related("user")
            .only(
                "pk", "company_name", "sector", "address", "is_verified",
                "logo", "banner", "user__user_type"
            )
        )

        # Parámetros
        q = (self.request.GET.get('q') or '').strip()
        sector = self.request.GET.get('sector') or ''
        tipo = (self.request.GET.get('tipo') or '').lower()   # '', 'pyme', 'distribuidor'
        order = self.request.GET.get('order') or 'name_asc'   # 'name_asc', 'name_desc', 'recent'

        # Filtros
        if q:
            qs = qs.filter(
                Q(company_name__icontains=q) |
                Q(address__icontains=q) |
                Q(sector__icontains=q)
            )
        if sector:
            qs = qs.filter(sector=sector)

        if tipo == 'pyme':
            qs = qs.filter(user__user_type='PYME')
        elif tipo == 'distribuidor':
            qs = qs.filter(user__user_type='DISTRIBUTOR')

        # Orden
        if order == 'name_desc':
            qs = qs.order_by('-company_name')
        elif order == 'recent':
            qs = qs.order_by('-pk')
        else:
            qs = qs.order_by('company_name')

        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)

        # Lista de sectores para el selector
        ctx['sectors'] = (
            Company.objects.filter(is_verified=True, is_active=True)
            .exclude(sector__isnull=True).exclude(sector__exact='')
            .values_list('sector', flat=True)
            .distinct()
            .order_by('sector')
        )

        # Parámetros actuales (para preservar en la UI)
        ctx['q'] = (self.request.GET.get('q') or '').strip()
        ctx['current_sector'] = self.request.GET.get('sector') or ''
        ctx['tipo'] = (self.request.GET.get('tipo') or '').lower()
        ctx['order'] = self.request.GET.get('order') or 'name_asc'

        # Para saber si el visitante tiene empresa (para CTA “Enviar mensaje”)
        ctx['my_company'] = getattr(self.request.user, 'company', None) if self.request.user.is_authenticated else None

        # Helper para mantener querystring en paginación
        params = self.request.GET.copy()
        if 'page' in params:
            params.pop('page')
        ctx['querystring'] = '&' + params.urlencode() if params else ''

        return ctx


# =====================================================
# Perfil de empresa
# =====================================================

class CompanyProfileView(DetailView):
    model = Company
    template_name = "perfil_negocio.html"
    context_object_name = "target_company"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        company = self.object

        # Publicadas visibles (excluye eliminadas)
        ctx["reviews"] = company.reviews.filter(
            status="PUBLISHED", is_deleted=False
        ).order_by("-created_at")

        # Form para crear reseña (si corresponde)
        ctx["review_form"] = ReviewForm()

        # ¿Puede moderar? (staff/superuser o dueño del perfil)
        u = self.request.user
        user_company_id = getattr(getattr(u, "company", None), "pk", None)
        can_moderate = u.is_authenticated and (
            u.is_staff or u.is_superuser or (user_company_id == company.pk)
        )
        ctx["can_moderate"] = can_moderate

        if can_moderate:
            # Ocultas (no eliminadas)
            ctx["reviews_hidden"] = company.reviews.filter(
                status="HIDDEN", is_deleted=False
            ).order_by("-created_at")

            # Eliminadas (soft)
            ctx["reviews_deleted"] = company.reviews.filter(
                is_deleted=True
            ).order_by("-deleted_at")

        return ctx

    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect("login")
        form = ReviewForm(request.POST)
        target_company = self.get_object()
        author_company = getattr(request.user, "company", None)
        if author_company and form.is_valid():
            review = form.save(commit=False)
            review.target_company = target_company
            review.author_company = author_company
            review.save()
            messages.success(request, "Reseña enviada.")
            return redirect("perfil_negocio", pk=target_company.pk)

        ctx = self.get_context_data(**kwargs)
        ctx["review_form"] = form
        return self.render_to_response(ctx)


class CompanyProfileEditView(LoginRequiredMixin, UpdateView):
    model = Company
    form_class = CompanyProfileForm
    template_name = 'perfil_negocio_edit.html'

    def get_object(self, queryset=None):
        return getattr(self.request.user, 'company', None)

    def get_success_url(self):
        messages.success(self.request, "Perfil actualizado.")
        return reverse('perfil_negocio', kwargs={'pk': self.object.pk})


# =====================================================
# Productos
# =====================================================

class ProductOwnerRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        obj = self.get_object()
        if getattr(self.request.user, 'user_type', '') == 'ADMIN' or self.request.user.is_superuser:
            return True
        user_company = getattr(self.request.user, 'company', None)
        if not user_company:
            return False
        return obj.company == user_company

    def handle_no_permission(self):
        messages.error(self.request, "No tienes permisos para esta acción.")
        return redirect('dashboard')


class ProductCreateView(LoginRequiredMixin, CreateView):
    model = Product
    form_class = ProductForm
    template_name = 'product_form.html'

    def form_valid(self, form):
        company = getattr(self.request.user, 'company', None)
        if not company:
            messages.error(self.request, "No tienes empresa asociada.")
            return redirect('dashboard')
        form.instance.company = company
        messages.success(self.request, "Producto creado correctamente.")
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('perfil_negocio', kwargs={'pk': self.request.user.company.pk})

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['product'] = None
        return ctx


class ProductUpdateView(LoginRequiredMixin, ProductOwnerRequiredMixin, UpdateView):
    model = Product
    form_class = ProductForm
    template_name = 'product_form.html'
    context_object_name = 'product'

    def form_valid(self, form):
        messages.success(self.request, "Producto actualizado correctamente.")
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('product_detail', kwargs={'pk': self.object.pk})


class ProductDeleteView(LoginRequiredMixin, ProductOwnerRequiredMixin, DeleteView):
    model = Product
    template_name = 'product_confirm_delete.html'

    def get_success_url(self):
        messages.success(self.request, "Producto eliminado.")
        return reverse('perfil_negocio', kwargs={'pk': self.request.user.company.pk})


class ProductDetailView(DetailView):
    model = Product
    template_name = 'product_detail.html'
    context_object_name = 'product'

class ProductCompareView(ListView):
    model = Product
    template_name = 'product_compare.html'
    context_object_name = 'products'
    paginate_by = 20  # opcional

    def get_queryset(self):
        qs = (
            Product.objects
            .select_related('company')
            .filter(is_active=True, company__is_active=True, company__is_verified=True)
        )

        q = self.request.GET.get('q', '').strip()
        sector = self.request.GET.get('sector', '').strip()
        min_price = self.request.GET.get('min_price', '').strip()
        max_price = self.request.GET.get('max_price', '').strip()
        order = self.request.GET.get('order', 'price_asc')

        if q:
            qs = qs.filter(Q(name__icontains=q) | Q(description__icontains=q))

        if sector:
            qs = qs.filter(company__sector__iexact=sector)

        if min_price.isdigit():
            qs = qs.filter(price__gte=min_price)
        if max_price.isdigit():
            qs = qs.filter(price__lte=max_price)

        # Orden
        ordering_map = {
            'price_asc': 'price',
            'price_desc': '-price',
            'name_asc': 'name',
            'name_desc': '-name',
            'company_asc': 'company__company_name',
            'company_desc': '-company__company_name',
        }
        qs = qs.order_by(ordering_map.get(order, 'price'))

        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['q'] = self.request.GET.get('q', '').strip()
        ctx['sector'] = self.request.GET.get('sector', '').strip()
        ctx['min_price'] = self.request.GET.get('min_price', '').strip()
        ctx['max_price'] = self.request.GET.get('max_price', '').strip()
        ctx['order'] = self.request.GET.get('order', 'price_asc')
        # Para un dropdown de sectores basado en compañías activas
        ctx['sectors'] = (
            Company.objects.filter(is_active=True)
            .exclude(sector__isnull=True).exclude(sector__exact='')
            .values_list('sector', flat=True).distinct().order_by('sector')
        )
        return ctx

# =====================================================
# Feed / Comentarios
# =====================================================

class FeedView(ListView):
    model = Post
    template_name = "feed.html"
    context_object_name = "post_list"
    paginate_by = 10

    def get_queryset(self):
        return (
            Post.objects
            .select_related("company")
            .prefetch_related(
                Prefetch("comments", queryset=Comment.objects.select_related("author"))
            )
            .annotate(comment_count=Count("comments"))
            .order_by("-created_at")
        )

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["now"] = now()
        ctx["post_form"] = PostForm()
        ctx["comment_form"] = CommentForm()
        return ctx

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated or not hasattr(request.user, "company"):
            messages.error(request, "Debes iniciar sesión con una empresa para publicar o comentar.")
            return redirect("login")

        # Crear publicación
        if "create_post" in request.POST:
            post_form = PostForm(request.POST)
            if post_form.is_valid():
                post = post_form.save(commit=False)
                post.company = request.user.company
                post.save()
                messages.success(request, "Publicación creada correctamente.")
            else:
                messages.error(request, "Revisa el contenido del post.")
            return redirect("feed")

        # Crear comentario
        if "create_comment" in request.POST:
            post_id = request.POST.get("post_id")
            form = CommentForm(request.POST)
            if not post_id:
                messages.error(request, "Publicación inválida.")
                return redirect("feed")

            post = get_object_or_404(Post, pk=post_id)
            if form.is_valid():
                comment = form.save(commit=False)
                comment.post = post
                comment.author = request.user.company
                comment.save()
                messages.success(request, "Comentario publicado.")
            else:
                messages.error(request, "Revisa el comentario.")
            return redirect("feed")

        return redirect("feed")


# =====================================================
# API de ubicaciones (mapa)
# =====================================================

def company_locations_api(request):
    companies = Company.objects.filter(
        latitude__isnull=False,
        longitude__isnull=False,
        is_verified=True,
        is_active=True,
    ).only("company_name", "latitude", "longitude", "pk")
    locations = [
        {
            "name": c.company_name,
            "lat": c.latitude,
            "lon": c.longitude,
            "url": reverse("perfil_negocio", kwargs={"pk": c.pk}),
        }
        for c in companies
    ]
    return JsonResponse(locations, safe=False)


# =====================================================
# Autogestión de cuenta
# =====================================================

@login_required
def account_settings(request):
    company = getattr(request.user, 'company', None)
    return render(request, "cuenta/account_settings.html", {"company": company})

@login_required
@require_POST
def company_toggle_active(request):
    company = getattr(request.user, 'company', None)
    if not company:
        messages.error(request, "No tienes empresa asociada.")
        return redirect("account_settings")
    company.is_active = not company.is_active
    company.save(update_fields=["is_active"])
    messages.success(request, f"Tu perfil ahora está {'visible' if company.is_active else 'oculto'}.")
    return redirect("account_settings")

@login_required
@require_POST
def account_delete(request):
    user = request.user
    logout(request)
    username = user.username
    user.delete()
    messages.success(request, f"La cuenta '{username}' fue eliminada.")
    return redirect("home")


# =====================================================
# Panel admin: gestión de usuarios
# =====================================================

@staff_member_required
def admin_users(request):
    q = request.GET.get("q", "").strip()
    status = request.GET.get("status", "")
    users = CustomUser.objects.all()

    if q:
        users = users.filter(
            Q(username__icontains=q) | Q(email__icontains=q) |
            Q(first_name__icontains=q) | Q(last_name__icontains=q)
        )

    if status == "active":
        users = users.filter(is_active=True)
    elif status == "inactive":
        users = users.filter(is_active=False)

    users = users.order_by("-date_joined")[:200]
    return render(request, "admin_users.html", {"users": users, "q": q, "status": status})

@staff_member_required
@require_POST
def admin_user_toggle_active(request, pk):
    user = get_object_or_404(CustomUser, pk=pk)
    user.is_active = not user.is_active
    user.save(update_fields=["is_active"])
    messages.success(request, f"Usuario '{user.username}' ahora está {'activo' if user.is_active else 'inactivo'}.")
    return redirect("admin_users")

@staff_member_required
@require_POST
def admin_user_delete(request, pk):
    user = get_object_or_404(CustomUser, pk=pk)
    username = user.username
    user.delete()
    messages.success(request, f"Usuario '{username}' eliminado.")
    return redirect("admin_users")


# =====================================================
# Moderación de reseñas (ocultar/publicar/eliminar/restaurar)
# =====================================================

# --- Acciones de moderación ---
@login_required
@require_POST
def review_hide(request, pk):
    review = get_object_or_404(Review, pk=pk)
    if not _can_moderate_review(request.user, review):
        messages.error(request, "No tienes permisos para moderar esta reseña.")
        return redirect("perfil_negocio", pk=review.target_company.pk)
    review.status = "HIDDEN"
    review.save(update_fields=["status"])
    messages.success(request, "La reseña fue ocultada.")
    return redirect("perfil_negocio", pk=review.target_company.pk)


@login_required
@require_POST
def review_publish(request, pk):
    review = get_object_or_404(Review, pk=pk)
    if not _can_moderate_review(request.user, review):
        messages.error(request, "No tienes permisos para moderar esta reseña.")
        return redirect("perfil_negocio", pk=review.target_company.pk)
    review.status = "PUBLISHED"
    review.save(update_fields=["status"])
    messages.success(request, "La reseña fue publicada nuevamente.")
    return redirect("perfil_negocio", pk=review.target_company.pk)


@login_required
@require_POST
def review_delete(request, pk):
    """Soft delete: no se pierde la reseña, queda restaurable."""
    review = get_object_or_404(Review, pk=pk)
    if not _can_moderate_review(request.user, review):
        messages.error(request, "No tienes permisos para eliminar esta reseña.")
        return redirect("perfil_negocio", pk=review.target_company.pk)
    company_pk = review.target_company.pk
    from django.utils import timezone
    review.is_deleted = True
    review.deleted_at = timezone.now()
    review.save(update_fields=["is_deleted", "deleted_at"])
    messages.success(request, "La reseña fue eliminada (puedes restaurarla luego).")
    return redirect("perfil_negocio", pk=company_pk)


@login_required
@require_POST
def review_restore(request, pk):
    review = get_object_or_404(Review, pk=pk)
    if not _can_moderate_review(request.user, review):
        messages.error(request, "No tienes permisos para restaurar esta reseña.")
        return redirect("perfil_negocio", pk=review.target_company.pk)
    company_pk = review.target_company.pk
    review.is_deleted = False
    review.deleted_at = None
    # Si quieres reactivarla publicada al restaurar, descomenta:
    # review.status = "PUBLISHED"
    review.save(update_fields=["is_deleted", "deleted_at"])  # agrega "status" si activaste la línea anterior
    messages.success(request, "Reseña restaurada correctamente.")
    return redirect("perfil_negocio", pk=company_pk)



# =====================================================
# Admin: Lookup RUT con SimpleAPI
# =====================================================

@staff_member_required
def admin_rut_lookup(request):
    rut_query = (request.GET.get("rut") or "").strip()
    simpleapi_data = None
    simpleapi_error = None
    attempts_log = ""
    company_match = None

    if rut_query:
        # consulta a SimpleAPI
        simpleapi_data, simpleapi_error, attempts_log = query_simpleapi_rut(rut_query)

        # busca coincidencia local
        rut_clean = rut_query.replace(".", "").replace(" ", "")
        company_match = (
            Company.objects.filter(Rut__iexact=rut_query).first()
            or Company.objects.filter(Rut__iexact=rut_clean).first()
        )

        if not simpleapi_data and simpleapi_error:
            messages.warning(request, simpleapi_error)

    ctx = {
        "rut_query": rut_query,
        "simpleapi_data": simpleapi_data,
        "simpleapi_error": simpleapi_error,
        "attempts_log": attempts_log,
        "company_match": company_match,
    }
    return render(request, "admin_rut_lookup.html", ctx)
