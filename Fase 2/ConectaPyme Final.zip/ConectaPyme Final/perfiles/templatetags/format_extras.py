from django import template

register = template.Library()

@register.filter
def rut_format(value: str):
    """
    Formatea '12345678-9' como '12.345.678-9'. Si viene vacío, devuelve '—'.
    No valida matemáticamente el DV (solo formato).
    """
    if not value:
        return "—"
    s = value.replace(".", "").replace(" ", "")
    if "-" not in s:
        return s  # ya vendrá normalizado por tu modelo; evitamos inventar DV
    body, dv = s.split("-", 1)
    try:
        body = body[::-1]
        chunks = [body[i:i+3] for i in range(0, len(body), 3)]
        body_fmt = ".".join(chunks)[::-1]
        return f"{body_fmt}-{dv.upper()}"
    except Exception:
        return value
