import requests
from django.db import models
from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from django.utils import timezone
from django.utils.text import slugify

# =========================
# Constantes de moderación
# =========================
REVIEW_STATUS = (
    ("PUBLISHED", "Publicado"),
    ("HIDDEN", "Oculto"),
    ("REMOVED", "Eliminado"),
)

COMMENT_STATUS = (
    ("PUBLISHED", "Publicado"),
    ("HIDDEN", "Oculto"),
    ("REMOVED", "Eliminado"),
)

REPORT_STATUS = (
    ("OPEN", "Abierto"),
    ("REVIEWED", "Revisado"),
    ("CLOSED", "Cerrado"),
)


# =========================
# Categorías
# =========================
class Category(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name="Nombre de la Categoría")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Categorías"


# =========================
# Publicaciones / Feed
# =========================
class Post(models.Model):
    company = models.ForeignKey('Company', on_delete=models.CASCADE, related_name='posts')
    content = models.TextField(verbose_name="Contenido")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'Publicación de {self.company.company_name}'


# =========================
# Empresa
# =========================
class Company(models.Model):
    # PK anclado al usuario (sin campo "id")
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, primary_key=True)
    company_name = models.CharField(max_length=255, verbose_name="Nombre de la Empresa", blank=False)

    # Contacto
    first_name = models.CharField(max_length=100, verbose_name="Nombre", blank=True)  # nuevo
    last_name = models.CharField(max_length=100, verbose_name="Apellido", blank=False)

    # Identificación y sector
    Rut = models.CharField(
        max_length=12,
        verbose_name="Rut",
        unique=True,
        validators=[
            RegexValidator(
                regex=r'^[0-9]{7,8}-[0-9Kk]{1}$',
                message='El Rut debe tener el formato 12345678-9'
            )
        ],
        help_text="Formato: 12345678-9 (sin puntos)",
    )
    sector = models.CharField(max_length=100, verbose_name="Sector", blank=False)

    # Ubicación
    address = models.TextField(verbose_name="Dirección", blank=False)
    country = models.CharField(max_length=100, verbose_name="Región", blank=True)
    city = models.CharField(max_length=100, verbose_name="Comuna", blank=True)
    latitude = models.FloatField(null=True, blank=True, verbose_name="Latitud")
    longitude = models.FloatField(null=True, blank=True, verbose_name="Longitud")

    # Teléfono (acepta fijo y móvil)
    phone = models.CharField(
        max_length=16,
        verbose_name="Teléfono",
        blank=False,
        validators=[
            RegexValidator(
                # +56 opcional; 9 dígitos comenzando en 2–9 (fijo o móvil)
                regex=r'^(\+56\s?)?[2-9]\d{8}$',
                message="Usa formato chileno: +569xxxxxxxx (móvil) o +562xxxxxxxx (fijo). También se acepta sin +56."
            )
        ]
    )

    # Branding
    logo = models.ImageField(upload_to='companies/logos/', blank=True, null=True, verbose_name="Logo")
    banner = models.ImageField(upload_to='companies/banners/', blank=True, null=True, verbose_name="Banner")

    # --- Visibilidad/estado de empresa ---
    is_active = models.BooleanField(default=True, verbose_name="Empresa visible")

    # --- Verificación (mejorada) ---
    is_verified = models.BooleanField(default=False, verbose_name="Verificado")
    verified_at = models.DateTimeField(null=True, blank=True, verbose_name="Verificado el")
    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="companies_verified",
        verbose_name="Verificado por"
    )
    verification_note = models.TextField(blank=True, verbose_name="Nota de verificación")

    def __str__(self):
        return self.company_name

    # -------- Helpers de verificación --------
    def verify(self, by_user=None, note: str = ""):
        """Marca la empresa como verificada con trazabilidad."""
        self.is_verified = True
        self.verified_at = timezone.now()
        self.verified_by = by_user
        if note:
            self.verification_note = note
        self.save(update_fields=["is_verified", "verified_at", "verified_by", "verification_note"])

    def unverify(self, by_user=None, note: str = ""):
        """Revierte la verificación (mantiene quién hizo el cambio y la nota)."""
        self.is_verified = False
        self.verified_at = None
        self.verified_by = by_user
        if note:
            self.verification_note = note
        self.save(update_fields=["is_verified", "verified_at", "verified_by", "verification_note"])

    # -------- Utilidades internas --------
    @staticmethod
    def _normalize_rut(raw: str) -> str:
        """Quita puntos/espacios y pone DV en mayúscula. No valida matemáticamente el DV."""
        if not raw:
            return raw
        s = raw.replace(".", "").replace(" ", "")
        if "-" in s:
            base, dv = s.split("-", 1)
            return f"{base}-{dv.upper()}"
        return s.upper()

    def save(self, *args, **kwargs):
        # Normaliza RUT antes de guardar
        if self.Rut:
            self.Rut = self._normalize_rut(self.Rut)

        # Geocodificación: solo si tenemos dirección y NO tenemos lat/lon
        if self.address and (self.latitude is None or self.longitude is None):
            try:
                url = 'https://nominatim.openstreetmap.org/search'
                params = {'q': self.address, 'format': 'json', 'limit': 1}
                headers = {'User-Agent': 'ConectaPyme/1.0 (contacto@tudominio.cl)'}
                resp = requests.get(url, params=params, headers=headers, timeout=5)
                resp.raise_for_status()
                results = resp.json()
                if results:
                    self.latitude = float(results[0].get('lat'))
                    self.longitude = float(results[0].get('lon'))
            except requests.exceptions.RequestException as e:
                print(f"[Geocoding] Error: {e}")

        super().save(*args, **kwargs)

    class Meta:
        ordering = ["company_name"]
        indexes = [
            models.Index(fields=["Rut"]),
            models.Index(fields=["sector"]),
            models.Index(fields=["is_verified"]),
            models.Index(fields=["is_active"]),
        ]


# =========================
# Productos
# =========================

from django.db import models

class Product(models.Model):
    company = models.ForeignKey(
        'Company',
        on_delete=models.CASCADE,
        related_name='products',
        verbose_name='Empresa'
    )
    name = models.CharField('Nombre del producto', max_length=150)
    price = models.DecimalField('Precio (CLP)', max_digits=10, decimal_places=0)
    stock = models.PositiveIntegerField('Stock disponible', default=0)
    description = models.TextField('Descripción', blank=True)
    image = models.ImageField('Imagen del producto', upload_to='products/', blank=True, null=True)
    is_active = models.BooleanField('Activo', default=True)
    created_at = models.DateTimeField('Fecha de creación', auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField('Última actualización', auto_now=True, null=True, blank=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Producto'
        verbose_name_plural = 'Productos'
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['price']),
        ]

    def __str__(self):
        return f"{self.name} ({self.company.company_name})"

    @property
    def formatted_price(self):
        """Devuelve el precio con formato CLP."""
        return f"${self.price:,.0f}".replace(',', '.')

    def stock_status(self):
        """Devuelve el estado textual del stock."""
        if self.stock == 0:
            return "Sin stock"
        elif self.stock < 5:
            return "Stock bajo"
        else:
            return "Disponible"

    def get_absolute_url(self):
        """Devuelve la URL del detalle del producto (usado por templates y admin)."""
        from django.urls import reverse
        return reverse('product_detail', kwargs={'pk': self.pk})


# =========================
# Reseñas (con moderación)
# =========================
class Review(models.Model):
    target_company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='reviews')
    author_company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='authored_reviews')
    rating = models.IntegerField(default=5, validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(verbose_name="Comentario")
    status = models.CharField(max_length=10, choices=REVIEW_STATUS, default="PUBLISHED")
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Reseña de {self.author_company.company_name} para {self.target_company.company_name}'

    class Meta:
        indexes = [models.Index(fields=["status"]), models.Index(fields=["created_at"])]


# =========================
# Comentarios de posts (con moderación)
# =========================
class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(Company, on_delete=models.CASCADE)
    text = models.TextField(verbose_name="Comentario")
    status = models.CharField(max_length=10, choices=COMMENT_STATUS, default="PUBLISHED")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']
        indexes = [models.Index(fields=["status"]), models.Index(fields=["created_at"])]

    def __str__(self):
        return f'Comentario de {self.author.company_name} en {self.post}'


# =========================
# Reportes de contenido
# =========================
class ContentReport(models.Model):
    REPORT_TARGET = (
        ("REVIEW", "Reseña"),
        ("COMMENT", "Comentario"),
    )
    target_type = models.CharField(max_length=7, choices=REPORT_TARGET)
    target_id = models.PositiveIntegerField()  # id del Review o Comment
    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    reason = models.TextField(blank=True)
    status = models.CharField(max_length=8, choices=REPORT_STATUS, default="OPEN")
    created_at = models.DateTimeField(auto_now_add=True)
    handled_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="reports_handled"
    )
    handled_at = models.DateTimeField(null=True, blank=True)
    note = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["target_type", "target_id"]),
            models.Index(fields=["status"]),
            models.Index(fields=["created_at"]),
        ]

    def __str__(self):
        return f"Reporte {self.get_target_type_display()} #{self.pk} → {self.status}"

    def close(self, user, note: str = ""):
        self.status = "CLOSED"
        self.handled_by = user
        self.handled_at = timezone.now()
        if note:
            self.note = note
        self.save(update_fields=["status", "handled_by", "handled_at", "note"])
