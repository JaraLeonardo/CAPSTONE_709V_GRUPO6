from django.test import TestCase
from django.contrib.auth import get_user_model
from .forms import CompanyProfileForm, ReviewForm, ProductForm, PostForm, CommentForm
from .models import Company, Category, Post

# Create your tests here.
# Creación de pruebas unitarias

class CompanyProfileFormTest(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(username="pruebaUsuario", password="12345")

    def test_valid_company_profile_form(self):
        form = CompanyProfileForm(data={
            'company_name': "Mi Empresa",
            'Rut': "12345678-9",
            'sector': "Tecnología",
            'address': "Calle Ejemplo 123",
            'country': "Chile",
            'city': "Santiago",
            'phone': "+56912345678",
            'last_name': "Pérez",
        })
        self.assertTrue(form.is_valid())

    def test_invalid_company_profile_form(self):
        # Hacemos que falte el rut a proposito, para así de un perfil invalido
        form = CompanyProfileForm(data={
            'company_name': "Mi Empresa",
            'sector': "Tecnología",
            'address': "Calle Falsa 1235",
            'phone': "+56912345678",
            'last_name': "Pérez",
        })
        self.assertFalse(form.is_valid())
        self.assertIn("Rut", form.errors)


class ReviewFormTest(TestCase):
    def test_review_form_valid(self):
        form = ReviewForm(data={'rating': 4, 'comment': "Muy buen servicio"})
        self.assertTrue(form.is_valid())

    def test_review_form_invalid_rating(self):
        form = ReviewForm(data={'rating': 10, 'comment': "Exagerado"})
        self.assertFalse(form.is_valid())
        self.assertIn("rating", form.errors)


class ProductFormTest(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name="Electrónica")

    def test_product_form_valid(self):
        form = ProductForm(data={
            'name': "Laptop",
            'category': self.category.id,
            'description': "Un laptop rápido",
            'price': 500000,
        })
        self.assertTrue(form.is_valid())


class PostFormTest(TestCase):
    def test_post_form_valid(self):
        form = PostForm(data={'content': "Nueva actualización de producto"})
        self.assertTrue(form.is_valid())

    def test_post_form_empty(self):
        form = PostForm(data={'content': ""})
        self.assertFalse(form.is_valid())


class CommentFormTest(TestCase):
    def test_comment_form_valid(self):
        form = CommentForm(data={'text': "Excelente publicación"})
        self.assertTrue(form.is_valid())

    def test_comment_form_empty(self):
        form = CommentForm(data={'text': ""})
        self.assertFalse(form.is_valid())
