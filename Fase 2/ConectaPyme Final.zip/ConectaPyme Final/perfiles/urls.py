from django.urls import path
from .views import (
    HomeView, FaqView, dashboard,
    admin_portal_dashboard, verify_company_admin, unverify_company_admin,
    CompanyListView, CompanyProfileView, CompanyProfileEditView,
    ProductCreateView, ProductUpdateView, ProductDeleteView, ProductDetailView,
    FeedView, company_locations_api,
    review_hide, review_publish, review_delete,admin_rut_lookup,review_restore,ProductCompareView
)

urlpatterns = [
    # Público / generales
    path('', HomeView.as_view(), name='home'),
    path('faq/', FaqView.as_view(), name='faq'),
    path('dashboard/', dashboard, name='dashboard'),

    # Portal admin (personalizado con base.html)
    path('admin/portal/', admin_portal_dashboard, name='admin_portal_dashboard'),
    path('admin/portal/verify/<int:pk>/', verify_company_admin, name='verify_company_admin'),
    path('admin/portal/unverify/<int:pk>/', unverify_company_admin, name='unverify_company_admin'),

    # Empresas públicas
    path('perfiles/company/', CompanyListView.as_view(), name='company_list'),
    path('perfiles/company/<int:pk>/', CompanyProfileView.as_view(), name='perfil_negocio'),
    path('perfiles/company/edit/', CompanyProfileEditView.as_view(), name='perfil_negocio_edit'),

    # Productos
    path('product/add/', ProductCreateView.as_view(), name='product_add'),
    path('product/<int:pk>/edit/', ProductUpdateView.as_view(), name='product_edit'),
    path('product/<int:pk>/delete/', ProductDeleteView.as_view(), name='product_delete'),
    path('product/<int:pk>/', ProductDetailView.as_view(), name='product_detail'),
    path('products/compare/', ProductCompareView.as_view(), name='product_compare'),

    # Feed
    path('feed/', FeedView.as_view(), name='feed'),

    # API ubicaciones
    path('api/company-locations/', company_locations_api, name='company_locations_api'),
    path('admin/portal/rut-lookup/', admin_rut_lookup, name='admin_rut_lookup'),

    # Moderación de reseñas (dueño/admin desde el sitio)
    path('reviews/<int:pk>/hide/', review_hide, name='review_hide'),
    path('reviews/<int:pk>/publish/', review_publish, name='review_publish'),
    path('reviews/<int:pk>/delete/', review_delete, name='review_delete'),
    path('reviews/<int:pk>/restore/', review_restore, name='review_restore'), 
]
