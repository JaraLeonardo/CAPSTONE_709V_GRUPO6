from django.contrib import admin
from django.utils.timezone import now
from core.admin_site import register_both
from .models import Company, Category, Product, Post, Review, Comment, ContentReport

@admin.action(description="Marcar seleccionadas como VERIFICADAS")
def action_verify(modeladmin, request, queryset):
    updated = queryset.update(is_verified=True, verified_at=now(), verified_by=request.user)
    modeladmin.message_user(request, f"{updated} empresas verificadas.")

@admin.action(description="Marcar seleccionadas como NO verificadas")
def action_unverify(modeladmin, request, queryset):
    updated = queryset.update(is_verified=False, verified_at=None, verified_by=request.user)
    modeladmin.message_user(request, f"{updated} empresas marcadas como NO verificadas.")

# perfiles/admin.py (sumar a lo que ya tienes)
@admin.action(description="Publicar reseñas seleccionadas")
def publish_reviews(modeladmin, request, queryset):
    count = queryset.update(status="PUBLISHED")
    modeladmin.message_user(request, f"{count} reseña(s) publicadas.")


class CompanyAdmin(admin.ModelAdmin):
    list_display = ("company_name", "user", "sector", "city", "country", "phone",
                    "is_verified", "verified_at", "verified_by", "is_active")
    list_filter = ("is_verified", "is_active", "sector", "country", "city")
    search_fields = ("company_name", "user__username", "Rut", "city", "country")
    autocomplete_fields = ("user",)
    ordering = ("-is_verified", "-verified_at", "company_name")
    actions = [action_verify, action_unverify]

class CategoryAdmin(admin.ModelAdmin):
    search_fields = ("name",)

class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "company", "price", "stock", "is_active")
    list_filter = ("is_active", "company")
    search_fields = ("name", "company__company_name")

class PostAdmin(admin.ModelAdmin):
    list_display = ("company", "created_at")
    list_filter = ("company", "created_at")

# --- Acción para ocultar reseñas seleccionadas ---
@admin.action(description="Ocultar reseñas seleccionadas")
def hide_reviews(modeladmin, request, queryset):
    count = queryset.update(status="HIDDEN")
    modeladmin.message_user(request, f"{count} reseñas ocultadas.")

class ReviewAdmin(admin.ModelAdmin):
    list_display = ("target_company", "author_company", "rating", "status", "created_at")
    list_filter = ("status", "rating", "created_at")
    search_fields = ("target_company__company_name", "author_company__company_name")
    actions = [hide_reviews, publish_reviews]  # <-- aquí


class CommentAdmin(admin.ModelAdmin):
    list_display = ("post", "author", "status", "created_at")
    list_filter = ("status", "created_at")
    search_fields = ("post__company__company_name", "author__company_name")

class ContentReportAdmin(admin.ModelAdmin):
    list_display = ("target_type", "target_id", "status", "created_at")
    list_filter = ("status", "target_type", "created_at")
    search_fields = ("target_id",)

for model, admin_cls in [
    (Company, CompanyAdmin),
    (Category, CategoryAdmin),
    (Product, ProductAdmin),
    (Post, PostAdmin),
    (Review, ReviewAdmin),
    (Comment, CommentAdmin),
    (ContentReport, ContentReportAdmin),
]:
    register_both(model, admin_cls)
