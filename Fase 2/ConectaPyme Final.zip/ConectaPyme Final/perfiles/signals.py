from django.db.models.signals import post_save
from django.dispatch import receiver
from django.urls import reverse
from .models import Review, Comment
from notificaciones.models import Notification
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
import json

def send_notification_realtime(recipient_pk, message):
    channel_layer = get_channel_layer()
    group_name = f'notifications_{recipient_pk}'
    
    async_to_sync(channel_layer.group_send)(
        group_name,
        {
            'type': 'send.notification', # Llama al método 'send_notification' en el consumer
            'message': message,
        }
    )

@receiver(post_save, sender=Review)
def create_review_notification(sender, instance, created, **kwargs):
    if created:
        recipient = instance.target_company
        verb = f'{instance.author_company.company_name} ha dejado una reseña en tu perfil.'
        # ... (código para crear la notificación en la BD)
        send_notification_realtime(recipient.pk, verb) 

@receiver(post_save, sender=Comment)
def create_comment_notification(sender, instance, created, **kwargs):
    if created:
        # ... (código para crear la notificación en la BD)
        if instance.post.company != instance.author:
            verb = f'{instance.author.company_name} ha comentado en tu publicación.'
            send_notification_realtime(instance.post.company.pk, verb) 
