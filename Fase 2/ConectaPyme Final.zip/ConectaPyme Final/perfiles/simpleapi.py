# perfiles/simpleapi.py
from typing import Tuple, Optional
import requests
from django.conf import settings

def query_simpleapi_rut(rut: str) -> Tuple[Optional[dict], Optional[str], str]:
    """
    Consulta SimpleAPI RUT v2.
    Retorna: (data, error, attempts_log)
      - data: dict con JSON si 200
      - error: str si fallo
      - attempts_log: str con detalle de intentos (para depurar en template)
    """
    rut_norm = rut.replace(".", "").replace(" ", "").upper()
    base = settings.SIMPLEAPI_RUT_BASE.rstrip("/")
    url = f"{base}/{rut_norm}"

    attempts = []
    last_status = None
    last_text = None

    headers_list = [
        {"Authorization": settings.SIMPLEAPI_KEY, "Accept": "application/json"},  # ✅ tu caso
        {"X-API-Key": settings.SIMPLEAPI_KEY, "Accept": "application/json"},      # fallback
    ]

    for headers in headers_list:
        try:
            resp = requests.get(url, headers=headers, timeout=settings.SIMPLEAPI_TIMEOUT)
            attempts.append(f"GET {url} [{resp.status_code}] hdrs={list(headers.keys())}")
            last_status, last_text = resp.status_code, resp.text

            if resp.status_code == 200:
                return resp.json(), None, "\n".join(attempts)

            # si no es 200, probamos el siguiente header
            if resp.status_code in (401, 403, 404, 429):
                continue
        except requests.RequestException as e:
            attempts.append(f"[error] {e}")

    # construir un error legible
    if last_status == 401:
        err = "401 No autorizado. La API key no tiene acceso a RUT v2 o el header no es el correcto."
    elif last_status == 404:
        err = "404 No encontrado (URL/RUT)."
    elif last_status == 429:
        err = "429 Límite excedido (consultas agotadas)."
    elif last_status:
        err = f"Error {last_status}: {last_text[:200]}"
    else:
        err = "No fue posible contactar al proveedor."

    return None, err, "\n".join(attempts)
