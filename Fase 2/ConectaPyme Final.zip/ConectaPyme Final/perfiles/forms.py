# perfiles/forms.py
from django import forms
from django.core.exceptions import ValidationError
from PIL import Image, UnidentifiedImageError
import re

from .models import Company, Review, Product, Post, Comment

# =========================
# Utilidades de validación
# =========================

def _rut_dv(num_str: str) -> str:
    total, factor = 0, 2
    for d in reversed(num_str):
        total += int(d) * factor
        factor = 2 if factor == 7 else factor + 1
    resto = 11 - (total % 11)
    if resto == 11:
        return "0"
    if resto == 10:
        return "K"
    return str(resto)

def normalize_and_validate_rut(raw: str) -> str:
    if not raw:
        raise ValidationError("El RUT es obligatorio.")
    s = re.sub(r"[^0-9kK]", "", str(raw))
    if len(s) < 2 or not s[:-1].isdigit():
        raise ValidationError("Formato de RUT inválido.")
    cuerpo, dv = s[:-1], s[-1].upper()
    if _rut_dv(cuerpo) != dv:
        raise ValidationError("RUT inválido: el dígito verificador no coincide.")
    return f"{int(cuerpo)}-{dv}"

def normalize_cl_phone(raw: str) -> str:
    if not raw:
        raise ValidationError("El teléfono es obligatorio.")
    digits = re.sub(r"\D", "", raw)
    if digits.startswith("56"):
        digits = digits[2:]
    # Chile: 9 dígitos (fijos y móviles)
    if len(digits) != 9 or not digits.isdigit():
        raise ValidationError(
            "Teléfono inválido. Usa 9 dígitos (móvil o fijo). Ej: +569XXXXXXXX o +562XXXXXXXX."
        )
    return f"+56{digits}"

def human_mb(num_bytes: int) -> str:
    return f"{num_bytes / (1024 * 1024):.1f} MB"

ALLOWED_IMG_FORMATS = {"PNG", "JPEG", "JPG", "WEBP"}

def validate_image(file, *, max_mb: int, min_size: tuple[int, int] | None = None):
    """
    Valida tamaño en MB, formato (png/jpg/webp) y opcionalmente dimensiones mínimas (w,h).
    """
    if not file:
        return

    size_bytes = getattr(file, "size", 0)
    if size_bytes and size_bytes > max_mb * 1024 * 1024:
        raise ValidationError(
            f"La imagen supera el máximo permitido de {max_mb} MB (tiene {human_mb(size_bytes)})."
        )

    # Validar formato y dimensiones
    pos = file.tell()
    try:
        img = Image.open(file)
        fmt = (img.format or "").upper()
        if fmt == "JPG":
            fmt = "JPEG"
        if fmt not in ALLOWED_IMG_FORMATS:
            raise ValidationError("Formato no permitido. Usa PNG, JPG/JPEG o WEBP.")
        if min_size:
            w, h = img.size
            if w < min_size[0] or h < min_size[1]:
                raise ValidationError(
                    f"Dimensiones muy pequeñas: {w}x{h}px. Mínimo {min_size[0]}x{min_size[1]}px."
                )
    except UnidentifiedImageError:
        raise ValidationError("El archivo no parece ser una imagen válida.")
    finally:
        # devolver el puntero para no romper el guardado
        try:
            file.seek(pos)
        except Exception:
            pass

def clean_person_name(value: str, field_label: str) -> str:
    v = (value or "").strip()
    if len(v) < 2:
        raise ValidationError(f"{field_label} es demasiado corto.")
    # Permitimos letras, espacios y apóstrofes básicos
    if not re.fullmatch(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ' ]+", v):
        raise ValidationError(f"{field_label} contiene caracteres inválidos.")
    return v.title()

def clean_text_title(value: str, field_label: str) -> str:
    v = (value or "").strip()
    if len(v) < 2:
        raise ValidationError(f"{field_label} es demasiado corto.")
    return v.title()

# =========================
# Formularios
# =========================

class CompanyProfileForm(forms.ModelForm):
    class Meta:
        model = Company
        fields = [
            "company_name", "Rut", "sector",
            "address", "country", "city",
            "phone", "first_name", "last_name",
            "logo", "banner",
        ]
        labels = {
            "company_name": "Nombre de la Empresa",
            "Rut": "RUT",
            "first_name": "Nombre",
            "last_name": "Apellido",
            "phone": "Teléfono",
            "country": "Región",
            "city": "Comuna",
            "logo": "Logo",
            "banner": "Banner",
        }
        help_texts = {
            "phone": "Ej.: +56912345678 (móvil) o +56223456789 (fijo). También se acepta sin +56.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["first_name"].required = True
        self.fields["sector"].widget.attrs.update({"list": "sectors"})
        self.fields["phone"].widget.attrs.setdefault("placeholder", "+569XXXXXXXX o +562XXXXXXXX")
        self.fields["company_name"].widget.attrs.setdefault("placeholder", "Tu marca o razón social")
        self.fields["address"].widget.attrs.setdefault("placeholder", "Calle, número, comuna")

    # ------- Cleaners de campos -------
    def clean_company_name(self):
        name = (self.cleaned_data.get("company_name") or "").strip()
        name = re.sub(r"\s{2,}", " ", name)
        if len(name) < 3:
            raise ValidationError("El nombre de la empresa es demasiado corto.")
        return name

    def clean_first_name(self):
        return clean_person_name(self.cleaned_data.get("first_name"), "Nombre")

    def clean_last_name(self):
        return clean_person_name(self.cleaned_data.get("last_name"), "Apellido")

    def clean_country(self):
        return clean_text_title(self.cleaned_data.get("country"), "Región")

    def clean_city(self):
        return clean_text_title(self.cleaned_data.get("city"), "Comuna")

    def clean_Rut(self):
        rut_norm = normalize_and_validate_rut(self.cleaned_data.get("Rut"))
        # Unicidad ignorando la instancia actual (edición)
        qs = Company.objects.filter(Rut__iexact=rut_norm)
        if self.instance and self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError("Ya existe otra empresa con este RUT.")
        return rut_norm

    def clean_phone(self):
        return normalize_cl_phone(self.cleaned_data.get("phone"))

    def clean_logo(self):
        file = self.cleaned_data.get("logo")
        # Logo: 3 MB máx, 128x128 mínimo
        validate_image(file, max_mb=3, min_size=(128, 128))
        return file

    def clean_banner(self):
        file = self.cleaned_data.get("banner")
        # Banner: 5 MB máx, 1200x300 mínimo (ratio apaisado recomendado)
        validate_image(file, max_mb=5, min_size=(1200, 300))
        return file


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ["rating", "comment"]
        widgets = {
            "rating": forms.RadioSelect(choices=[(i, f"{i} estrellas") for i in range(1, 6)]),
            "comment": forms.Textarea(attrs={"rows": 3, "placeholder": "Escribe tu reseña aquí..."}),
        }
        labels = {"rating": "Tu Calificación"}

    def clean_comment(self):
        text = (self.cleaned_data.get("comment") or "").strip()
        if len(text) < 3:
            raise ValidationError("El comentario es demasiado corto.")
        if len(text) > 2000:
            raise ValidationError("El comentario es demasiado largo (máx. 2000 caracteres).")
        return text


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["name", "price", "stock", "description", "image", "is_active"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre"}),
            "price": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": "0"}),
            "stock": forms.NumberInput(attrs={"class": "form-control", "min": "0"}),
            "description": forms.Textarea(
                attrs={"class": "form-control", "rows": 4, "placeholder": "Descripción"}
            ),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean_name(self):
        return (self.cleaned_data.get("name") or "").strip()

    def clean_price(self):
        price = self.cleaned_data.get("price")
        if price is None:
            return price
        if price < 0:
            raise ValidationError("El precio no puede ser negativo.")
        return price

    def clean_stock(self):
        stock = self.cleaned_data.get("stock")
        if stock is None:
            return stock
        if stock < 0:
            raise ValidationError("El stock no puede ser negativo.")
        return stock

    def clean_description(self):
        desc = (self.cleaned_data.get("description") or "").strip()
        if len(desc) > 4000:
            raise ValidationError("La descripción es muy larga (máx. 4000 caracteres).")
        return desc

    def clean_image(self):
        file = self.cleaned_data.get("image")
        # Imagen de producto: 4 MB máx, 400x400 mínimo
        validate_image(file, max_mb=4, min_size=(400, 400))
        return file


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ["content"]
        widgets = {
            "content": forms.Textarea(
                attrs={"rows": 3, "placeholder": "¿Qué estás pensando?"}
            )
        }
        labels = {"content": ""}

    def clean_content(self):
        txt = (self.cleaned_data.get("content") or "").strip()
        if len(txt) < 2:
            raise ValidationError("El contenido es demasiado corto.")
        if len(txt) > 2000:
            raise ValidationError("El contenido es demasiado largo (máx. 2000 caracteres).")
        return txt


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["text"]
        widgets = {
            "text": forms.TextInput(
                attrs={"placeholder": "Añade un comentario...", "class": "form-control"}
            )
        }
        labels = {"text": ""}

    def clean_text(self):
        txt = (self.cleaned_data.get("text") or "").strip()
        if len(txt) < 2:
            raise ValidationError("El comentario es demasiado corto.")
        if len(txt) > 500:
            raise ValidationError("El comentario es demasiado largo (máx. 500 caracteres).")
        return txt



class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ["content"]
        widgets = {
            "content": forms.Textarea(attrs={
                "rows": 3,
                "placeholder": "Comparte una novedad o una actualización sobre tu empresa..."
            })
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["text"]
        widgets = {
            "text": forms.Textarea(attrs={
                "rows": 2,
                "placeholder": "Escribe un comentario..."
            })
        }
