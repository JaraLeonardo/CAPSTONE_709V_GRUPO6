# Cuenta/views.py
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import (
    PasswordChangeView,
    PasswordResetView,
    PasswordResetConfirmView,
)
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.decorators.http import require_POST

from .forms import PymeRegistrationForm, DistributorRegistrationForm
from .models import CustomUser


# =========================
# Registro
# =========================
def register_options(request):
    return render(request, "registration/register_options.html")


def register_pyme(request):
    if request.method == "POST":
        form = PymeRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "¡Registro PyME exitoso! Bienvenido/a 👋")
            return redirect(settings.LOGIN_REDIRECT_URL)  # p.ej. 'dashboard'
    else:
        form = PymeRegistrationForm()
    return render(request, "registration/register_pyme.html", {"form": form})


def register_distributor(request):
    if request.method == "POST":
        form = DistributorRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "¡Registro de Distribuidor exitoso! Bienvenido/a 👋")
            return redirect(settings.LOGIN_REDIRECT_URL)
    else:
        form = DistributorRegistrationForm()
    return render(request, "registration/register_distributor.html", {"form": form})


# =========================
# Password (logged in + reset)
# =========================
class UserPasswordChangeView(PasswordChangeView):
    template_name = "account/password_change.html"
    success_url = reverse_lazy("dashboard")

    def form_valid(self, form):
        messages.success(self.request, "Tu contraseña se actualizó correctamente.")
        return super().form_valid(form)


class UserPasswordResetView(PasswordResetView):
    template_name = "account/password_reset_form.html"
    email_template_name = "account/password_reset_email.html"  # opcional si lo tienes
    subject_template_name = "account/password_reset_subject.txt"
    success_url = reverse_lazy("password_reset_done")


class UserPasswordResetConfirmView(PasswordResetConfirmView):
    template_name = "account/password_reset_confirm.html"
    success_url = reverse_lazy("password_reset_complete")


# =========================
# Ajustes de cuenta (usuario)
# =========================
@login_required
def account_settings(request):
    """Página de ajustes de cuenta del usuario final."""
    company = getattr(request.user, "company", None)
    return render(request, "cuenta/account_settings.html", {"company": company})


@login_required
@require_POST
def company_toggle_active(request):
    """Alterna la visibilidad pública de la empresa del usuario."""
    company = getattr(request.user, "company", None)
    if not company:
        messages.error(request, "No tienes empresa asociada.")
        return redirect("account_settings")

    company.is_active = not company.is_active
    company.save(update_fields=["is_active"])
    messages.success(
        request,
        f"Tu perfil ahora está {'visible' if company.is_active else 'oculto'}.",
    )
    return redirect("account_settings")


@login_required
@require_POST
def account_delete(request):
    """Elimina la cuenta del usuario autenticado (y cierra sesión)."""
    username = request.user.username
    logout(request)
    # Nota: Si tienes relaciones con on_delete=CASCADE, esto borrará asociado.
    CustomUser.objects.filter(username=username).delete()
    messages.success(request, f"La cuenta '{username}' fue eliminada correctamente.")
    return redirect("home")


# =========================
# Panel admin: gestión de usuarios
# =========================
@staff_member_required
def admin_users(request):
    """
    Listado y filtro básico de usuarios para staff.
    Templates:
      - cuenta/admin_users.html
    Query params:
      - q: búsqueda libre (username, email, nombre, apellido)
      - status: "active" | "inactive" | ""(todos)
      - type: "PYME" | "DISTRIBUTOR" | "MODERATOR" | "ADMIN" | ""(todos)
    """
    q = request.GET.get("q", "").strip()
    status = request.GET.get("status", "").strip()
    utype = request.GET.get("type", "").strip()

    users = CustomUser.objects.all().order_by("-date_joined")

    if q:
        users = users.filter(
            Q(username__icontains=q)
            | Q(email__icontains=q)
            | Q(first_name__icontains=q)
            | Q(last_name__icontains=q)
        )

    if status == "active":
        users = users.filter(is_active=True)
    elif status == "inactive":
        users = users.filter(is_active=False)

    if utype in {"PYME", "DISTRIBUTOR", "MODERATOR", "ADMIN"}:
        users = users.filter(user_type=utype)

    context = {
        "users": users,
        "q": q,
        "status": status,
        "utype": utype,
    }
    return render(request, "cuenta/admin_users.html", context)


@staff_member_required
@require_POST
def admin_user_toggle_active(request, pk):
    """Activa/Desactiva un usuario (solo staff)."""
    user = get_object_or_404(CustomUser, pk=pk)
    user.is_active = not user.is_active
    user.save(update_fields=["is_active"])
    messages.success(
        request,
        f"El usuario '{user.username}' ahora está {'activo' if user.is_active else 'inactivo'}.",
    )
    return redirect("admin_users")


@staff_member_required
@require_POST
def admin_user_delete(request, pk):
    """Elimina un usuario (solo staff)."""
    user = get_object_or_404(CustomUser, pk=pk)
    username = user.username
    user.delete()
    messages.success(request, f"El usuario '{username}' fue eliminado.")
    return redirect("admin_users")
