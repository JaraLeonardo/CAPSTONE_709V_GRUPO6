# Cuenta/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from .views import (
    register_options, register_pyme, register_distributor,
    UserPasswordChangeView, UserPasswordResetConfirmView, UserPasswordResetView,
    account_settings, company_toggle_active, account_delete,
    admin_users, admin_user_toggle_active, admin_user_delete,
)

urlpatterns = [
    # Auth
    path('login/',  auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'),

    # Registro
    path('register/', register_options, name='register_options'),
    path('register/pyme/', register_pyme, name='register_pyme'),
    path('register/distributor/', register_distributor, name='register_distributor'),

    # Reset password
    path('password_reset/', UserPasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/',
         auth_views.PasswordResetDoneView.as_view(template_name='account/password_reset_done.html'),
         name='password_reset_done'),
    path('reset/<uidb64>/<token>/', UserPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/',
         auth_views.PasswordResetCompleteView.as_view(template_name='account/password_reset_complete.html'),
         name='password_reset_complete'),

    # Change password (logueado)
    path('password_change/', UserPasswordChangeView.as_view(), name='password_change'),

    # Ajustes de cuenta (usuario final)
    path('settings/', account_settings, name='account_settings'),
    path('settings/company-toggle/', company_toggle_active, name='company_toggle_active'),
    path('settings/delete/', account_delete, name='account_delete'),

    # Admin: gestión de usuarios
    path('admin/users/', admin_users, name='admin_users'),
    path('admin/users/<int:pk>/toggle/', admin_user_toggle_active, name='admin_user_toggle_active'),
    path('admin/users/<int:pk>/delete/', admin_user_delete, name='admin_user_delete'),
]
