# Cuenta/forms.py
from django import forms
from django.db import transaction
from django.core.exceptions import ValidationError
from django.core.validators import validate_email, RegexValidator
from django.contrib.auth import get_user_model
from perfiles.models import Company
import re

CustomUser = get_user_model()

# ---------- Utilidades de validación ----------

USERNAME_VALIDATOR = RegexValidator(
    regex=r'^[\w.@+-]+$',
    message="Sólo se permiten letras, números y los símbolos @ . + - _",
)

def _rut_dv(num_str: str) -> str:
    """
    Calcula dígito verificador de un RUT chileno (cuerpo numérico sin DV).
    """
    total, factor = 0, 2
    for d in reversed(num_str):
        total += int(d) * factor
        factor = 2 if factor == 7 else factor + 1
    resto = 11 - (total % 11)
    if resto == 11:
        return "0"
    if resto == 10:
        return "K"
    return str(resto)

def normalize_and_validate_rut(raw: str) -> str:
    """
    Normaliza y valida RUT. Devuelve 'XXXXXXXX-D' (sin puntos, con guión).
    """
    if not raw:
        raise ValidationError("El RUT es obligatorio.")
    s = re.sub(r"[^0-9kK]", "", str(raw))
    if len(s) < 2 or not s[:-1].isdigit():
        raise ValidationError("Formato de RUT inválido.")
    cuerpo, dv = s[:-1], s[-1].upper()
    dv_calc = _rut_dv(cuerpo)
    if dv != dv_calc:
        raise ValidationError("RUT inválido: el dígito verificador no coincide.")
    return f"{int(cuerpo)}-{dv}"

def normalize_cl_phone(raw: str) -> str:
    """
    Normaliza teléfonos chilenos a +56XXXXXXXXX (9 dígitos luego de +56).
    Acepta móviles y fijos. Desde 2019 todos tienen 9 dígitos.
    """
    if not raw:
        raise ValidationError("El teléfono es obligatorio.")
    digits = re.sub(r"\D", "", raw)
    if digits.startswith("56"):
        digits = digits[2:]
    if len(digits) != 9 or not digits.isdigit():
        raise ValidationError(
            "El número debe tener 9 dígitos (móvil o fijo). Ej: +569XXXXXXXX o +562XXXXXXXX."
        )
    return f"+56{digits}"

def validate_password_rules(pwd: str):
    errs = []
    if len(pwd or "") < 8:
        errs.append("La contraseña debe tener al menos 8 caracteres.")
    if not re.search(r"\d", pwd or ""):
        errs.append("La contraseña debe contener al menos un número.")
    if not re.search(r"[A-ZÁÉÍÓÚÑ]", pwd or ""):
        errs.append("La contraseña debe contener al menos una mayúscula.")
    if errs:
        raise ValidationError(errs)

# ---------- Formularios ----------

class BaseRegistrationForm(forms.ModelForm):
    # Campos de usuario
    username = forms.CharField(
        label="Nombre de Usuario",
        validators=[USERNAME_VALIDATOR],
        error_messages={'required': 'El nombre de usuario es obligatorio.'}
    )
    email = forms.EmailField(
        label="Email",
        error_messages={
            'required': 'El email es obligatorio.',
            'invalid': 'Introduce un correo electrónico válido.'
        }
    )
    password = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput,
        error_messages={'required': 'Debes crear una contraseña.'}
    )
    password_confirm = forms.CharField(
        label="Confirmar Contraseña",
        widget=forms.PasswordInput,
        error_messages={'required': 'Por favor, confirma tu contraseña.'}
    )

    # Campos de empresa
    company_name = forms.CharField(label="Nombre de la Empresa")
    Rut = forms.CharField(label="RUT")
    SECTOR_CHOICES = [
        ('comercio', 'Comercio'),
        ('servicios', 'Servicios'),
        ('tecnologia', 'Tecnología'),
        ('manufactura', 'Manufactura'),
        ('musica', 'Música'),
    ]
    sector = forms.ChoiceField(
        label="Sector",
        choices=SECTOR_CHOICES,
        required=True,
        error_messages={'required': 'Debes seleccionar un sector.'}
    )
    address = forms.CharField(
        label="Dirección",
        widget=forms.Textarea(attrs={'rows': 2}),
        error_messages={'required': 'Necesitamos saber tu dirección.'}
    )
    country = forms.CharField(
        label="Región",
        error_messages={'required': 'Por favor, ingresa tu región.'}
    )
    city = forms.CharField(
        label="Comuna",
        error_messages={'required': 'Por favor, ingresa tu comuna.'}
    )
    phone = forms.CharField(
        label="Teléfono",
        error_messages={'required': 'Tu número de teléfono es necesario.'}
    )
    first_name = forms.CharField(label="Nombre", required=True)
    last_name = forms.CharField(label="Apellido", required=True)

    terms_and_conditions = forms.BooleanField(
        label="Acepto los Términos de Servicio y la Política de Privacidad",
        required=True,
        error_messages={'required': 'Debes aceptar los términos y condiciones para continuar.'}
    )

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'first_name', 'last_name']
        labels = {
            'username': 'Nombre de Usuario',
            'first_name': 'Nombre',
            'last_name': 'Apellido',
        }

    # ------- Validaciones -------
    def clean_username(self):
        username = (self.cleaned_data.get('username') or '').strip()
        USERNAME_VALIDATOR(username)
        if CustomUser.objects.filter(username__iexact=username).exists():
            raise ValidationError("Este nombre de usuario ya está en uso.")
        return username

    def clean_email(self):
        email = (self.cleaned_data.get('email') or '').strip().lower()
        validate_email(email)
        if CustomUser.objects.filter(email__iexact=email).exists():
            raise ValidationError("Ya existe una cuenta registrada con este email.")
        return email

    def clean_Rut(self):
        rut_raw = self.cleaned_data.get('Rut')
        rut_norm = normalize_and_validate_rut(rut_raw)
        if Company.objects.filter(Rut__iexact=rut_norm).exists():
            raise ValidationError("Ya existe una empresa registrada con este RUT.")
        return rut_norm

    def clean_phone(self):
        return normalize_cl_phone(self.cleaned_data.get('phone'))

    def clean_password(self):
        pwd = self.cleaned_data.get('password')
        validate_password_rules(pwd)
        return pwd

    def clean(self):
        cleaned = super().clean()
        pwd = cleaned.get('password')
        pwd2 = cleaned.get('password_confirm')
        if pwd and pwd2 and pwd != pwd2:
            raise ValidationError("Las contraseñas no coinciden.")
        return cleaned

    # ------- Guardado -------
    @transaction.atomic
    def save(self, user_type: str, commit=True):
        user = CustomUser.objects.create_user(
            username=self.cleaned_data['username'],
            email=self.cleaned_data['email'],
            first_name=self.cleaned_data['first_name'],
            last_name=self.cleaned_data['last_name'],
            password=self.cleaned_data['password'],
        )
        user.user_type = user_type
        user.save(update_fields=['user_type'])

        Company.objects.create(
            user=user,
            company_name=self.cleaned_data['company_name'],
            Rut=self.cleaned_data['Rut'],
            sector=self.cleaned_data['sector'],
            address=self.cleaned_data['address'],
            country=self.cleaned_data['country'],
            city=self.cleaned_data['city'],
            phone=self.cleaned_data['phone'],
            first_name=self.cleaned_data['first_name'],
            last_name=self.cleaned_data['last_name'],
        )
        return user

class PymeRegistrationForm(BaseRegistrationForm):
    def save(self, commit=True):
        return super().save(user_type='PYME', commit=commit)

class DistributorRegistrationForm(BaseRegistrationForm):
    def save(self, commit=True):
        return super().save(user_type='DISTRIBUTOR', commit=commit)
