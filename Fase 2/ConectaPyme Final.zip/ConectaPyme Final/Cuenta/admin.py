# Cuenta/admin.py
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.utils.translation import gettext_lazy as _
from .models import CustomUser
from core.admin_site import register_both

class CustomUserAdmin(DjangoUserAdmin):
    list_display = ("username", "email", "first_name", "last_name", "user_type", "is_active", "date_joined")
    list_filter = ("user_type", "is_active", "is_staff", "is_superuser", "date_joined")
    search_fields = ("username", "email", "first_name", "last_name")
    ordering = ("-date_joined",)
    fieldsets = DjangoUserAdmin.fieldsets + ((_("Negocio"), {"fields": ("user_type",)}),)
    add_fieldsets = DjangoUserAdmin.add_fieldsets + ((_("Negocio"), {"fields": ("user_type",)}),)

register_both(CustomUser, CustomUserAdmin)
