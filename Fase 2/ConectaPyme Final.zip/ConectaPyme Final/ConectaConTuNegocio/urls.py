from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from core.admin_site import admin_site
from perfiles.views import (
    admin_portal_dashboard, verify_company_admin, unverify_company_admin,admin_rut_lookup
)

urlpatterns = [
    # Portal admin propio (vistas personalizadas)
    path('admin/portal/', admin_portal_dashboard, name='admin_portal_dashboard'),
    path('admin/portal/verify/<int:pk>/', verify_company_admin, name='verify_company_admin'),
    path('admin/portal/unverify/<int:pk>/', unverify_company_admin, name='unverify_company_admin'),
    path('admin/portal/rut-lookup/', admin_rut_lookup, name='admin_rut_lookup'),

    # Admin clásico de Django (el de siempre)
    path('admin/', admin.site.urls),

    # AdminSite personalizado (separado)
    path('cp-admin/', admin_site.urls),

    # Apps
    path('accounts/', include('Cuenta.urls')),
    path('mensajes/', include('mensajeria.urls')),
    path('notificaciones/', include('notificaciones.urls')),
    path('', include('perfiles.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
