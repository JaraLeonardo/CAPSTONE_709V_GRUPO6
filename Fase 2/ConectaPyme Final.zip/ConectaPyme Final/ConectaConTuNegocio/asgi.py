import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack

# Importamos AMBOS archivos de enrutamiento
import mensajeria.routing
import notificaciones.routing

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ConectaConTuNegocio.settings')

application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": AuthMiddlewareStack(
        URLRouter(
            mensajeria.routing.websocket_urlpatterns +
            notificaciones.routing.websocket_urlpatterns
        )
    ),
})