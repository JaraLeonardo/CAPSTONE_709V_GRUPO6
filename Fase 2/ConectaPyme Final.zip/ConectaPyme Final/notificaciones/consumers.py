import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async

class NotificationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope['user']
        if not self.user.is_authenticated or not hasattr(self.user, 'company'):
            await self.close()
        else:
            # Cada usuario se une a un "grupo" único basado en el ID de su empresa.
            # Así podemos enviarle notificaciones solo a él.
            self.room_group_name = f'notifications_{self.user.company.pk}'

            await self.channel_layer.group_add(
                self.room_group_name,
                self.channel_name
            )
            await self.accept()

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )

    # Este método se llama cuando enviamos una notificación desde el backend (las señales)
    async def send_notification(self, event):
        # Envía el mensaje por el WebSocket al frontend (JavaScript)
        await self.send(text_data=json.dumps({
            'type': 'notification',
            'message': event['message'],
        }))