from django.db import models
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey

class Notification(models.Model):
    recipient = models.ForeignKey('perfiles.Company', on_delete=models.CASCADE, related_name='notifications')
    sender = models.ForeignKey('perfiles.Company', on_delete=models.CASCADE, null=True, blank=True, related_name='sent_notifications')
    verb = models.CharField(max_length=255)
    target_url = models.URLField(max_length=200, null=True, blank=True)
    read = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now_add=True)

    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True, blank=True)
    object_id = models.PositiveIntegerField(null=True, blank=True)
    target = GenericForeignKey('content_type', 'object_id')
    
    # Un contador para las notificaciones agrupadas
    count = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f'Notificación para {self.recipient.company_name}: {self.verb}'