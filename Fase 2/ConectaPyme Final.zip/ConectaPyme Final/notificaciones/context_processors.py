from .models import Notification

def notifications_context(request):
    if request.user.is_authenticated and hasattr(request.user, 'company'):
        unread_notifications = Notification.objects.filter(
            recipient=request.user.company, 
            read=False
        ).order_by('-timestamp')
        
        unread_count = unread_notifications.count()
        recent_notifications = unread_notifications[:5]
        
        return {
            'unread_notification_count': unread_count,
            'recent_notifications': recent_notifications
        }
    return {}