from django.shortcuts import render
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Notification

class NotificationListView(LoginRequiredMixin, ListView):
    model = Notification
    template_name = 'notificaciones/notification_list.html'
    context_object_name = 'notifications'

    def get_queryset(self):
        # Primero, verificamos si el usuario tiene una empresa asociada
        if hasattr(self.request.user, 'company'):
            # Si tiene, filtramos las notificaciones para esa empresa
            queryset = super().get_queryset().filter(recipient=self.request.user.company)
            # Marcamos las notificaciones como leídas al verlas
            queryset.filter(read=False).update(read=True)
            return queryset
        
        # Si no tiene empresa (es Admin o Usuario Común), devolvemos una lista vacía
        return Notification.objects.none()